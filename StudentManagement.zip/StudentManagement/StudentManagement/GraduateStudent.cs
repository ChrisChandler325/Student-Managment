﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.RightsManagement;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace StudentManagement
{
    class GraduateStudent : Person
    {
        private int id;
        private int grad;
        public override void addCourse(Course course)
        {
            if(course.Num >= 5000 && course.Num <= 9999) { base.addCourse(course);}
            else { MessageBox.Show("An Undergraduate class must be of 1000 - 4999 level"); }
        }
        public int Grad 
        {
            get { return grad; }
            set { grad = value; }
        }
        public int Id
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
            }
        }
        public override string ToString()
        {
            return this.LastName + " " + this.FirstName;
        }
    }
}
