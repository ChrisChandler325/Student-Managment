﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StudentManagement
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        
        BindingList<Person> people = new BindingList<Person>();
        
        
        public MainWindow()
        {
            InitializeComponent();
            StudentsListBox.ItemsSource = people;
            MessageBox.Show("No exception handling. Can't edit after creating student/course.")
        }
        private void AddStudentButton_Click(object sender, RoutedEventArgs e)
        {
            people.Add(GetStudent());
            StudentsListBox.Items.Refresh();
        }
        private void AddCourseButton_Click(object sender, RoutedEventArgs e)
        {
            Course course = new Course();
            course.Name = CourseNameTextBox.Text;
            course.Prefix= CoursePrefixTextBox.Text;
            course.Num = Convert.ToInt32(CourseNumberTextBox.Text);
            course.Hrs = Convert.ToInt32(CreditHoursTextBox.Text);
            course.Grade = Convert.ToDouble(GPATextBox.Text);
            foreach (Person person in people)
            {
                if(person == (Person)StudentsListBox.SelectedItem)
                {

                    person.addCourse(course);
                    getGpa(person.courses);
                    CoursessListBox.Items.Refresh();
                }
            }
        }
        private void populateText(object sender, RoutedEventArgs e)
        {
            foreach(Person a in people)
            {
                if(a == (Person)StudentsListBox.SelectedItem)
                {
                    CoursessListBox.ItemsSource = a.courses;
                    getGpa(a.courses);
                    CoursessListBox.Items.Refresh();
                }
            }
        }
        private Person GetStudent()
        {
            string fname = FirstNameTextBox.Text;
            string lname = LastNameTextBox.Text;
            int gender = GenderBox.SelectedIndex;
            int gradBox = GradBox.SelectedIndex;
            int id = Convert.ToInt32(StudentIDTextBox.Text);
            int age = Convert.ToInt32(AgeTextBox.Text);
            string grad = GradBox.Text;
            if (grad.ToLower() == "undergraduate")
            {
                UnderGraduateStudent student = new UnderGraduateStudent();
                return makeUnder(fname, lname, gender, id, age, gradBox);
            }
            else
            {
                GraduateStudent student = new GraduateStudent();
                return makeGrad(fname, lname, gender, id, age, gradBox);
            }
        }
        private UnderGraduateStudent makeUnder(string fname, string lname, int gender, int id, int age, int gradBox)
        {
            UnderGraduateStudent student = new UnderGraduateStudent();
            student.FirstName = fname;
            student.LastName = lname;
            student.Gender = gender;
            student.Id= id;
            student.Age = age;
            student.Grad = gradBox;
            return student;
        }
        private GraduateStudent makeGrad(string fname, string lname, int gender, int id, int age, int gradBox)
        {
            GraduateStudent student = new GraduateStudent();
            student.FirstName = fname;
            student.LastName = lname;
            student.Gender = gender;
            student.Id = id;
            student.Age = age;
            student.Grad = gradBox;
            return student;
        }
        private void getGpa(List<Course> courses)
        {
            if (courses != null)
            {
                double? top = 0;
                double? bottom = 0;
                foreach (Course course in courses)
                {
                    top += course.Grade * course.Hrs;
                    bottom += course.Hrs;
                }
                TotalGPATextBox.Text = (top / bottom).ToString();
            }
        }
    }
}
