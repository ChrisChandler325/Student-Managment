﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement
{
    public class Course
    {
        public string? Name { get; set; }
        public string? Prefix { get; set; }
        public int? Num { get; set; }
        public int? Hrs { get; set; }
        public double? Grade { get; set; }

        public override string ToString()
        {
            return this.Num + " " + this.Name;
        }
    }

}
